public interface Beobachter {
    public void aktualisieren(Zug[] gleise);
}
